# developme-technical-challange

To start up the project locally, pull all the files from the github repo in to a folder on you pc or mac.
open the index.html (found in the root directory) on a browser (chrome, firefox etc)
this should open the page and you can begin

note: this has been tested in firefox, safari and chrome but not in IE or Edge.
